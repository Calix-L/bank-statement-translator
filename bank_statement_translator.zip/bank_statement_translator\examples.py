"""Example usage scripts for bank statement translator."""

import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from config import get_settings
from config_validator import ConfigValidator
from excel_generator import ExcelGenerator
from pdf_parser import PDFParser
from statement_structurer import StatementStructurer
from translator import StatementTranslator


def example_basic_usage():
    """Basic single file processing example."""
    print("=" * 50)
    print("Example: Basic Usage")
    print("=" * 50)
    
    # Initialize
    settings = get_settings()
    parser = PDFParser(settings)
    translator = StatementTranslator(settings)
    
    # Check config
    if not settings.zhipu_api_key:
        print("❌ Please configure ZHIPU_API_KEY in .env first")
        return
    
    # Process PDF
    pdf_path = Path("test_statement.pdf")
    if not pdf_path.exists():
        print(f"❌ File not found: {pdf_path}")
        return
    
    print(f"📄 Processing: {pdf_path}")
    
    # Read
    pdf_bytes = pdf_path.read_bytes()
    
    # Validate
    ok, msg = parser.validate_pdf(pdf_bytes)
    if not ok:
        print(f"❌ Validation failed: {msg}")
        return
    
    # Extract & Parse
    pages = parser.extract_text_by_page(pdf_bytes)
    rows = StatementStructurer.parse(pages)
    df = StatementStructurer.to_dataframe(rows)
    
    print(f"📊 Found {len(df)} transactions")
    
    # Translate
    translated_df = translator.translate_dataframe(df)
    
    # Export
    excel_bytes = ExcelGenerator.generate(translated_df, df)
    output_path = Path("example_output.xlsx")
    output_path.write_bytes(excel_bytes)
    
    print(f"✅ Saved to: {output_path}")


def example_batch_processing():
    """Batch processing example."""
    print("=" * 50)
    print("Example: Batch Processing")
    print("=" * 50)
    
    settings = get_settings()
    parser = PDFParser(settings)
    translator = StatementTranslator(settings)
    
    if not settings.zhipu_api_key:
        print("❌ Please configure ZHIPU_API_KEY in .env first")
        return
    
    # Find all PDFs
    pdf_files = list(Path(".").glob("*.pdf"))
    if not pdf_files:
        print("❌ No PDF files found")
        return
    
    print(f"Found {len(pdf_files)} PDF files")
    
    results = []
    for pdf_path in pdf_files:
        try:
            pdf_bytes = pdf_path.read_bytes()
            ok, _ = parser.validate_pdf(pdf_bytes)
            
            if not ok:
                continue
            
            pages = parser.extract_text_by_page(pdf_bytes)
            rows = StatementStructurer.parse(pages)
            df = StatementStructurer.to_dataframe(rows)
            translated_df = translator.translate_dataframe(df)
            
            excel_bytes = ExcelGenerator.generate(translated_df, df)
            output_path = pdf_path.with_suffix(".xlsx")
            output_path.write_bytes(excel_bytes)
            
            results.append((pdf_path.name, True))
            print(f"  ✅ {pdf_path.name} -> {output_path.name}")
            
        except Exception as e:
            results.append((pdf_path.name, False))
            print(f"  ❌ {pdf_path.name}: {e}")
    
    successful = sum(1 for _, ok in results if ok)
    print(f"\n📊 Processed: {successful}/{len(results)} files")


def example_config_check():
    """Check configuration example."""
    print("=" * 50)
    print("Example: Configuration Check")
    print("=" * 50)
    
    ConfigValidator.print_report()


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Usage examples")
    parser.add_argument("example", choices=["basic", "batch", "config"], 
                       help="Which example to run")
    
    args = parser.parse_args()
    
    if args.example == "basic":
        example_basic_usage()
    elif args.example == "batch":
        example_batch_processing()
    elif args.example == "config":
        example_config_check()
