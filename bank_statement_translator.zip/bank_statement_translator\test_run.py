"""Test script for bank statement translator."""

import sys

import pandas as pd

sys.path.insert(0, '.')

from config import get_settings
from excel_generator import ExcelGenerator
from pdf_parser import PDFParser
from statement_structurer import StatementStructurer
from translator import CHINESE_RE, TRANSLATABLE_COLUMNS, StatementTranslator


def find_chinese_cells(df: pd.DataFrame, columns: tuple[str, ...]) -> list[tuple[int, str, str]]:
    """Find cells that still contain Chinese characters."""
    issues: list[tuple[int, str, str]] = []
    for column in columns:
        if column not in df.columns:
            continue
        for idx, value in df[column].fillna("").astype(str).items():
            if CHINESE_RE.search(value):
                issues.append((idx, column, value))
    return issues


def main():
    """Main test function."""
    # Load settings (from config.py or .env file)
    settings = get_settings()

    # Load PDF
    with open("test_statement.pdf", "rb") as f:
        pdf_bytes = f.read()

    print(f"PDF size: {len(pdf_bytes) / 1024:.1f} KB")

    # Parse PDF
    parser = PDFParser(settings)
    ok, msg = parser.validate_pdf(pdf_bytes)
    print(f"Validation: {ok} - {msg}")

    if not ok:
        print(f"PDF validation failed: {msg}")
        sys.exit(1)

    # Extract text
    page_texts = parser.extract_text_by_page(pdf_bytes)
    print(f"Pages extracted: {len(page_texts)}")
    print(f"First page chars: {len(page_texts[0]) if page_texts else 0}")

    # Check if text is sparse
    is_sparse = parser.is_text_sparse(page_texts)
    print(f"Text is sparse: {is_sparse}")

    # Structure data
    rows = StatementStructurer.parse(page_texts)
    print(f"Rows parsed: {len(rows)}")

    if not rows:
        print("No rows parsed!")
        sys.exit(1)

    df = StatementStructurer.to_dataframe(rows)
    print(f"DataFrame shape: {df.shape}")
    print(df.head(3))

    # Translate
    translator = StatementTranslator(settings)
    translated_df = translator.translate_dataframe(df)
    print("\nTranslated:")
    print(translated_df.head(3))

    residual_chinese = find_chinese_cells(translated_df, TRANSLATABLE_COLUMNS)
    print(f"\nResidual Chinese cells in DataFrame: {len(residual_chinese)}")
    if residual_chinese:
        for idx, column, value in residual_chinese[:10]:
            print(f"  row={idx}, column={column}, value={value}")

    # Generate Excel
    excel_bytes = ExcelGenerator.generate(translated_df=translated_df, raw_df=df)
    with open("output.xlsx", "wb") as f:
        f.write(excel_bytes)
    print(f"\nExcel saved: {len(excel_bytes)} bytes")

    # Verify Excel
    translated_sheet = pd.read_excel("output.xlsx", sheet_name="Translated")
    excel_chinese = []
    for column in translated_sheet.columns:
        for idx, value in translated_sheet[column].fillna("").astype(str).items():
            if CHINESE_RE.search(value):
                excel_chinese.append((idx, column, value))

    print(f"Residual Chinese cells in Excel sheet: {len(excel_chinese)}")
    if excel_chinese:
        for idx, column, value in excel_chinese[:10]:
            print(f"  excel_row={idx}, column={column}, value={value}")
        raise AssertionError("Translated Excel still contains Chinese text.")

    print("Verification passed: translated Excel contains no Chinese text.")


if __name__ == "__main__":
    main()
