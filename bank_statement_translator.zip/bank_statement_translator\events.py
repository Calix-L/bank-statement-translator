"""Event system for hooking into processing pipeline."""

from __future__ import annotations

from typing import Any, Callable, Dict, List
from enum import Enum


class Event(str, Enum):
    """Events emitted during processing."""
    FILE_START = "file_start"
    FILE_END = "file_end"
    VALIDATE_START = "validate_start"
    VALIDATE_END = "validate_end"
    EXTRACT_START = "extract_start"
    EXTRACT_END = "extract_end"
    PARSE_START = "parse_start"
    PARSE_END = "parse_end"
    TRANSLATE_START = "translate_start"
    TRANSLATE_END = "translate_end"
    GENERATE_START = "generate_start"
    GENERATE_END = "generate_end"
    ERROR = "error"
    COMPLETE = "complete"


class EventEmitter:
    """Simple event emitter for processing hooks."""
    
    def __init__(self):
        self._listeners: Dict[Event, List[Callable]] = {}
    
    def on(self, event: Event, callback: Callable) -> None:
        """Register an event listener.
        
        Args:
            event: Event to listen for
            callback: Function to call when event fires
        """
        if event not in self._listeners:
            self._listeners[event] = []
        self._listeners[event].append(callback)
    
    def off(self, event: Event, callback: Callable) -> None:
        """Remove an event listener.
        
        Args:
            event: Event to stop listening for
            callback: Callback to remove
        """
        if event in self._listeners:
            try:
                self._listeners[event].remove(callback)
            except ValueError:
                pass
    
    def emit(self, event: Event, data: Any = None) -> None:
        """Emit an event.
        
        Args:
            event: Event to emit
            data: Optional data to pass to callbacks
        """
        if event in self._listeners:
            for callback in self._listeners[event]:
                try:
                    callback(event, data)
                except Exception:
                    pass  # Don't let listener errors break processing
    
    def once(self, event: Event, callback: Callable) -> None:
        """Register a one-time event listener.
        
        Args:
            event: Event to listen for
            callback: Function to call when event fires
        """
        def wrapper(e: Event, d: Any = None):
            callback(e, d)
            self.off(event, wrapper)
        
        self.on(event, wrapper)
    
    def clear(self, event: Event | None = None) -> None:
        """Clear event listeners.
        
        Args:
            event: Specific event to clear, or None to clear all
        """
        if event is None:
            self._listeners.clear()
        elif event in self._listeners:
            self._listeners[event].clear()


# Global event emitter
_events: EventEmitter | None = None


def get_events() -> EventEmitter:
    """Get global event emitter."""
    global _events
    if _events is None:
        _events = EventEmitter()
    return _events


# Convenience decorators
def on(event: Event):
    """Decorator to register an event listener."""
    def decorator(func: Callable):
        get_events().on(event, func)
        return func
    return decorator


def once(event: Event):
    """Decorator to register a one-time event listener."""
    def decorator(func: Callable):
        get_events().once(event, func)
        return func
    return decorator
