# 🏦 Bank Statement Translator / 银行流水翻译工具

[English](#english) | [中文](#中文)

---

## English

### Overview

A powerful Python toolkit for converting Chinese bank statement PDFs into structured, English-language Excel files. Perfect for visa applications, financial compliance reviews, and international accounting workflows.

### Features

| Feature | Description |
|---------|-------------|
| 📄 **PDF Extraction** | Processes both text-based and image-heavy PDFs with OCR fallback |
| 🔍 **Smart OCR** | Handles scanned documents with Baidu Cloud OCR integration |
| 🌐 **Terminology-Aware** | 500+ banking terms, payment platforms, merchant names, cities |
| 📊 **Structured Parsing** | Converts unstructured text into clean tabular data |
| 📥 **Batch Processing** | Process multiple PDFs simultaneously |
| 📑 **Excel Export** | Visa-ready output with translated + original sheets |
| 💾 **Caching** | Built-in translation cache for 10x faster repeated processing |
| ⚡ **Rate Limiting** | Smart API rate limiting to prevent throttling |
| 🐳 **Docker Ready** | One-click deployment with Docker |
| ✅ **Well Tested** | Comprehensive test suite with CI/CD |

### Quick Start

#### 1. Installation

```bash
# Clone the repo
git clone https://github.com/Calix-L/bank-statement-translator.git
cd bank-statement-translator

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# or
.venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt
```

#### 2. Configuration

```bash
# Copy configuration template
cp .env.example .env

# Edit .env with your API keys:
# - ZHIPU_API_KEY: Get from https://open.bigmodel.cn/
# - OCR_TOKEN (optional): Get from https://aistudio.baidu.com/
```

#### 3. Run

**Web Interface:**
```bash
streamlit run app.py
# Open http://localhost:8501
```

**Command Line:**
```bash
# Validate configuration
python -m bank_statement_translator validate

# Process single file
python -m bank_statement_translator process statement.pdf

# Batch process
python -m bank_statement_translator batch file1.pdf file2.pdf
```

**Docker:**
```bash
docker-compose up -d
# Visit http://localhost:8501
```

### Supported Banks / 支持的银行

| Status | Bank |
|--------|------|
| ✅ Full | Industrial and Commercial Bank of China (ICBC) |
| 🔶 Framework | Bank of China (BOC) |
| 🔶 Framework | Agricultural Bank of China (ABC) |
| 🔶 Framework | China Construction Bank (CCB) |

### Output Format / 输出格式

| Column | Description |
|--------|-------------|
| Transaction Date | Date of transaction |
| Account Number | Bank account number |
| Description | Transaction description (translated) |
| Income/Expenditure Amount | Transaction amount |
| Balance | Account balance after transaction |
| Counterparty Name | Other party's name |
| Region | Transaction location |
| Channel | Transaction channel (ATM, Online, etc.) |

### Project Structure

```
.
├── app.py                    # Streamlit web UI
├── cli.py                    # Command-line interface
├── config.py                 # Configuration management
├── translator.py             # Translation engine
├── pdf_parser.py            # PDF/OCR processing
├── excel_generator.py        # Excel output
├── cache.py                  # Translation caching
├── rate_limiter.py           # API rate limiting
├── validators.py             # Data validation
├── parsers/                  # Bank-specific parsers
├── tests/                    # Test suite
├── utils/                    # Utility functions
├── Dockerfile                # Container image
├── docker-compose.yml        # Container orchestration
├── Makefile                  # Development shortcuts
└── README.md                 # This file
```

### API Keys Required

| API | Required |获取方式 |
|-----|----------|----------|
| Zhipu GLM | ✅ Yes | https://open.bigmodel.cn |
| Baidu OCR | ❌ Optional | https://aistudio.baidu.com |

### Development

```bash
# Install dev dependencies
make install

# Run tests
make test

# Format code
make format

# Lint code
make lint

# Validate config
make validate
```

### License

MIT License

### Contributing

Contributions welcome! Please submit a Pull Request.

---

## 中文

### 简介

一款强大的Python工具包，用于将中文银行流水PDF转换为结构化的英文Excel文件。适用于签证申请、财务合规审查、国际会计工作流等场景。

### 功能特性

| 特性 | 描述 |
|------|------|
| 📄 **PDF提取** | 支持文本型PDF和图片型PDF，OCR自动降级 |
| 🔍 **智能OCR** | 集成百度云OCR处理扫描件 |
| 🌐 **术语感知** | 500+银行术语、支付平台、商户名称、城市 |
| 📊 **结构化解析** | 将非结构化文本转换为清晰的表格数据 |
| 📥 **批量处理** | 支持同时处理多个PDF文件 |
| 📑 **Excel导出** | 签证-ready输出，包含翻译版和原始版 |
| 💾 **缓存加速** | 内置翻译缓存，重复处理提速10倍 |
| ⚡ **速率限制** | 智能API限流，防止被封禁 |
| 🐳 **Docker支持** | 一键Docker部署 |
| ✅ **完善测试** | 完整测试套件 + CI/CD |

### 快速开始

#### 1. 安装

```bash
# 克隆仓库
git clone https://github.com/Calix-L/bank-statement-translator.git
cd bank-statement-translator

# 创建虚拟环境
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# 或
.venv\Scripts\activate  # Windows

# 安装依赖
pip install -r requirements.txt
```

#### 2. 配置

```bash
# 复制配置模板
cp .env.example .env

# 编辑 .env 填入你的API密钥:
# - ZHIPU_API_KEY: 从 https://open.bigmodel.cn/ 获取
# - OCR_TOKEN (可选): 从 https://aistudio.baidu.com/ 获取
```

#### 3. 运行

**Web界面:**
```bash
streamlit run app.py
# 打开 http://localhost:8501
```

**命令行:**
```bash
# 验证配置
python -m bank_statement_translator validate

# 处理单个文件
python -m bank_statement_translator process statement.pdf

# 批量处理
python -m bank_statement_translator batch file1.pdf file2.pdf
```

**Docker:**
```bash
docker-compose up -d
# 访问 http://localhost:8501
```

### 输出字段说明

| 字段 | 说明 |
|------|------|
| 交易日期 | 交易发生的日期 |
| 账号 | 银行账号 |
| 摘要 | 交易描述（已翻译） |
| 收入/支出金额 | 交易金额 |
| 余额 | 交易后账户余额 |
| 对方户名 | 交易对方名称 |
| 地区 | 交易发生地区 |
| 渠道 | 交易渠道（柜员机、网银等） |

### 项目结构

```
.
├── app.py                    # Streamlit Web界面
├── cli.py                    # 命令行工具
├── config.py                 # 配置管理
├── translator.py             # 翻译引擎
├── pdf_parser.py            # PDF/OCR处理
├── excel_generator.py        # Excel导出
├── cache.py                  # 翻译缓存
├── rate_limiter.py           # API限流
├── validators.py             # 数据验证
├── parsers/                  # 银行专用解析器
├── tests/                    # 测试套件
├── utils/                    # 工具函数
├── Dockerfile                # 容器镜像
├── docker-compose.yml        # 容器编排
├── Makefile                  # 开发快捷命令
└── README.md                 # 本文件
```

### 所需API密钥

| API | 必需 | 获取方式 |
|-----|------|----------|
| 智谱GLM | ✅ 是 | https://open.bigmodel.cn |
| 百度OCR | ❌ 可选 | https://aistudio.baidu.com |

### 开发指南

```bash
# 安装开发依赖
make install

# 运行测试
make test

# 代码格式化
make format

# 代码检查
make lint

# 验证配置
make validate
```

### 许可证

MIT License

### 贡献

欢迎提交Pull Request！

---

**Stars / 点赞** ⭐ 欢迎支持！
