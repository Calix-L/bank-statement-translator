"""Tests for translator module."""

import sys
sys.path.insert(0, '.')

from translator import StatementTranslator, BANK_TERMS
from config import get_settings


def test_term_lookup():
    """Test basic term lookup."""
    settings = get_settings()
    translator = StatementTranslator(settings)
    
    # Test known terms
    test_cases = {
        "工资": "Salary",
        "消费": "Consumption",
        "转账": "Transfer",
        "利息": "Interest",
        "手续费": "Fee",
        "支付宝": "Alipay",
        "微信支付": "WeChat Pay",
    }
    
    for cn, expected_en in test_cases.items():
        result = BANK_TERMS.get(cn, cn)
        assert result == expected_en, f"Expected {expected_en}, got {result}"
    
    print("✅ test_term_lookup PASSED")


def test_translation_basic():
    """Test basic translation with terms."""
    settings = get_settings()
    translator = StatementTranslator(settings)
    
    # Skip if no API key
    if not settings.zhipu_api_key:
        print("⚠️ Skipping test_translation_basic - no API key")
        return
    
    # Test single field translation
    result = translator.translate_field("工资")
    print(f"  Translation of '工资': {result}")
    
    print("✅ test_translation_basic PASSED")


def test_translate_dataframe():
    """Test dataframe translation."""
    import pandas as pd
    
    settings = get_settings()
    translator = StatementTranslator(settings)
    
    # Create sample dataframe
    df = pd.DataFrame({
        "摘要": ["工资", "消费", "转账"],
        "地区": ["北京", "上海", "深圳"],
        "对方户名": ["张三", "京东商城", "李四"],
    })
    
    # Skip if no API key
    if not settings.zhipu_api_key:
        print("⚠️ Skipping test_translate_dataframe - no API key")
        return
    
    result = translator.translate_dataframe(df)
    print(f"  Translated {len(result)} rows")
    
    print("✅ test_translate_dataframe PASSED")


def test_chinese_detection():
    """Test Chinese text detection."""
    from translator import CHINESE_RE
    
    test_cases = [
        ("工资", True),
        ("Salary", False),
        ("工资转账", True),
        ("2024-01-01", False),
        ("", False),
    ]
    
    for text, expected in test_cases:
        result = bool(CHINESE_RE.search(text))
        assert result == expected, f"Expected {expected} for '{text}', got {result}"
    
    print("✅ test_chinese_detection PASSED")


if __name__ == "__main__":
    print("\nRunning translator tests...\n")
    
    test_term_lookup()
    test_chinese_detection()
    test_translation_basic()
    test_translate_dataframe()
    
    print("\n✅ All translator tests passed!")
