"""CLI entry point for bank statement translator."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from config import get_settings
from config_validator import ConfigValidator
from excel_generator import ExcelGenerator
from logger import setup_logger
from pdf_parser import PDFParser
from statement_structurer import StatementStructurer
from translator import StatementTranslator


logger = setup_logger("bank_statement_translator.cli")


def validate_config() -> bool:
    """Validate configuration before running."""
    return ConfigValidator.print_report()


def process_single_file(
    pdf_path: Path,
    output_path: Path | None = None,
    include_raw: bool = True,
) -> bool:
    """Process a single PDF file.
    
    Args:
        pdf_path: Path to input PDF file
        output_path: Path to output Excel file (optional)
        include_raw: Whether to include raw data sheet
        
    Returns:
        True if successful
    """
    settings = get_settings()
    parser = PDFParser(settings)
    translator = StatementTranslator(settings)
    
    # Read PDF
    print(f"Reading {pdf_path}...")
    pdf_bytes = pdf_path.read_bytes()
    
    # Validate
    print("Validating PDF...")
    ok, msg = parser.validate_pdf(pdf_bytes)
    if not ok:
        print(f"❌ Validation failed: {msg}")
        return False
    
    # Extract
    print("Extracting text...")
    page_texts = parser.extract_text_by_page(pdf_bytes)
    print(f"  Extracted {len(page_texts)} pages")
    
    # Parse
    print("Parsing transactions...")
    rows = StatementStructurer.parse(page_texts)
    print(f"  Found {len(rows)} transactions")
    
    if not rows:
        print("❌ No transactions found in PDF")
        return False
    
    df = StatementStructurer.to_dataframe(rows)
    
    # Translate
    print("Translating...")
    translated_df = translator.translate_dataframe(df)
    
    # Generate Excel
    print("Generating Excel...")
    raw_df = df if include_raw else None
    excel_bytes = ExcelGenerator.generate(translated_df, raw_df)
    
    # Save
    if output_path is None:
        output_path = pdf_path.with_suffix(".xlsx")
    
    output_path.write_bytes(excel_bytes)
    print(f"✅ Saved to {output_path}")
    
    return True


def process_batch(
    pdf_files: list[Path],
    output_dir: Path | None = None,
) -> bool:
    """Process multiple PDF files.
    
    Args:
        pdf_files: List of input PDF paths
        output_dir: Directory for output files (optional)
        
    Returns:
        True if all successful
    """
    settings = get_settings()
    parser = PDFParser(settings)
    translator = StatementTranslator(settings)
    
    if output_dir is None:
        output_dir = Path(".")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    results = []
    
    for i, pdf_path in enumerate(pdf_files):
        print(f"\n[{i+1}/{len(pdf_files)}] Processing {pdf_path.name}...")
        
        try:
            pdf_bytes = pdf_path.read_bytes()
            
            ok, msg = parser.validate_pdf(pdf_bytes)
            if not ok:
                print(f"  ❌ Validation failed: {msg}")
                results.append((pdf_path.name, False))
                continue
            
            page_texts = parser.extract_text_by_page(pdf_bytes)
            rows = StatementStructurer.parse(page_texts)
            
            if not rows:
                print(f"  ⚠️ No transactions found")
                results.append((pdf_path.name, False))
                continue
            
            df = StatementStructurer.to_dataframe(rows)
            translated_df = translator.translate_dataframe(df)
            
            # Generate separate Excel for each file
            excel_bytes = ExcelGenerator.generate(translated_df, df)
            
            output_path = output_dir / f"{pdf_path.stem}_translated.xlsx"
            output_path.write_bytes(excel_bytes)
            
            print(f"  ✅ {len(rows)} transactions -> {output_path.name}")
            results.append((pdf_path.name, True))
            
        except Exception as e:
            print(f"  ❌ Error: {e}")
            results.append((pdf_path.name, False))
    
    # Summary
    print("\n" + "=" * 50)
    print("Batch Processing Summary")
    print("=" * 50)
    
    successful = sum(1 for _, ok in results if ok)
    total = len(results)
    
    for name, ok in results:
        status = "✅" if ok else "❌"
        print(f"{status} {name}")
    
    print(f"\nTotal: {successful}/{total} files processed successfully")
    
    return successful == total


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Bank Statement Translator - Convert Chinese bank PDFs to English Excel",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Validate configuration
  python -m bank_statement_translator validate
  
  # Process a single file
  python -m bank_statement_translator process statement.pdf
  
  # Process with custom output
  python -m bank_statement_translator process statement.pdf -o output.xlsx
  
  # Process multiple files
  python -m bank_statement_translator batch file1.pdf file2.pdf file3.pdf
  
  # Process all PDFs in current directory
  python -m bank_statement_translator batch *.pdf
        """,
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Validate command
    subparsers.add_parser("validate", help="Validate configuration")
    
    # Process command
    process_parser = subparsers.add_parser("process", help="Process a single PDF file")
    process_parser.add_argument("input", type=Path, help="Input PDF file")
    process_parser.add_argument("-o", "--output", type=Path, help="Output Excel file")
    process_parser.add_argument("--no-raw", action="store_true", help="Exclude raw data sheet")
    
    # Batch command
    batch_parser = subparsers.add_parser("batch", help="Process multiple PDF files")
    batch_parser.add_argument("inputs", type=Path, nargs="+", help="Input PDF files")
    batch_parser.add_argument("-o", "--output-dir", type=Path, help="Output directory")
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        return 1
    
    if args.command == "validate":
        success = validate_config()
        return 0 if success else 1
    
    if args.command == "process":
        success = process_single_file(
            args.input,
            args.output,
            include_raw=not args.no_raw,
        )
        return 0 if success else 1
    
    if args.command == "batch":
        success = process_batch(args.inputs, args.output_dir)
        return 0 if success else 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
