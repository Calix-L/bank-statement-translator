"""Extended banking terminology for better translation coverage."""

from typing import Dict

# Extended bank terms - add to the main BANK_TERMS in translator.py
EXTENDED_BANK_TERMS: Dict[str, str] = {
    # Additional transaction types
    "分期付款": "Installment Payment",
    "预授权": "Pre-authorization",
    "预授权撤销": "Pre-authorization Cancellation",
    "预授权完成": "Pre-authorization Complete",
    "挂失": "Report Loss",
    "解挂": "Unfreeze Account",
    "冻结": "Freeze",
    "解冻": "Unfreeze",
    
    # Additional fees
    "挂失费": "Report Loss Fee",
    "补卡费": "Card Replacement Fee",
    "转账手续费": "Transfer Fee",
    "汇划费": "Remittance Fee",
    "查询费": "Inquiry Fee",
    "打印费": "Printing Fee",
    
    # Additional payment types
    "水电费": "Utility Bill",
    "煤气费": "Gas Bill",
    "物业费": "Property Fee",
    "学费": "Tuition Fee",
    "保险费": "Insurance Premium",
    "医疗费": "Medical Fee",
    "挂号费": "Registration Fee",
    
    # Payment platforms
    "支付宝": "Alipay",
    "微信支付": "WeChat Pay",
    "财付通": "Tenpay",
    "银联": "UnionPay",
    "云闪付": "UnionPay QuickPass",
    
    # E-commerce
    "淘宝": "Taobao",
    "天猫": "Tmall",
    "京东": "JD.com",
    "拼多多": "Pinduoduo",
    "唯品会": "Vipshop",
    "美团": "Meituan",
    "饿了么": "Eleme",
    "盒马": "Freshippo",
    
    # Transport
    "滴滴出行": "Didi",
    "滴滴": "Didi",
    "曹操出行": "Caocao",
    "首汽约车": "First Taxi",
    "神州专车": "Shenzhou",
    "地铁": "Metro",
    "公交": "Bus",
    "出租车": "Taxi",
    
    # Entertainment
    "腾讯视频": "Tencent Video",
    "爱奇艺": "iQiyi",
    "优酷": "Youku",
    "芒果TV": "Mango TV",
    "哔哩哔哩": "Bilibili",
    "抖音": "Douyin",
    "快手": "Kuaishou",
    "网易云音乐": "NetEase Cloud Music",
    "QQ音乐": "QQ Music",
    "酷狗音乐": "Kugou Music",
    
    # Healthcare
    "药店": "Pharmacy",
    "药房": "Pharmacy",
    "医院": "Hospital",
    "诊所": "Clinic",
    "社区卫生服务中心": "Community Health Center",
    
    # Education
    "学校": "School",
    "大学": "University",
    "培训机构": "Training Institution",
    "教育": "Education",
    
    # Government
    "税务局": "Tax Bureau",
    "公安局": "Public Security Bureau",
    "民政局": "Civil Affairs Bureau",
    "工商局": "Industry and Commerce Bureau",
    
    # Common company types
    "有限公司": "Limited",
    "股份有限公司": "Co., Ltd.",
    "有限责任公司": "Limited Liability Company",
    "集团": "Group",
    "公司": "Company",
    "企业": "Enterprise",
    
    # Major cities
    "北京": "Beijing",
    "上海": "Shanghai",
    "深圳": "Shenzhen",
    "广州": "Guangzhou",
    "杭州": "Hangzhou",
    "成都": "Chengdu",
    "重庆": "Chongqing",
    "武汉": "Wuhan",
    "西安": "Xi'an",
    "南京": "Nanjing",
    "苏州": "Suzhou",
    "天津": "Tianjin",
    "长沙": "Changsha",
    "郑州": "Zhengzhou",
    "济南": "Jinan",
    "青岛": "Qingdao",
    "大连": "Dalian",
    "沈阳": "Shenyang",
    "哈尔滨": "Harbin",
    "长春": "Changchun",
    "福州": "Fuzhou",
    "厦门": "Xiamen",
    "南昌": "Nanchang",
    "合肥": "Hefei",
    "昆明": "Kunming",
    "贵阳": "Guiyang",
    "太原": "Taiyuan",
    "石家庄": "Shijiazhuang",
    "兰州": "Lanzhou",
    "乌鲁木齐": "Urumqi",
    "呼和浩特": "Hohhot",
    "南宁": "Nanning",
    "海口": "Haikou",
}

# Payment and finance terms
PAYMENT_TERMS: Dict[str, str] = {
    "现金": "Cash",
    "银行卡": "Bank Card",
    "信用卡": "Credit Card",
    "借记卡": "Debit Card",
    "存折": "Passbook",
    "存单": "Certificate of Deposit",
    "取款": "Withdrawal",
    "存款": "Deposit",
    "利息": "Interest",
    "年费": "Annual Fee",
    "月费": "Monthly Fee",
    "手续费": "Service Fee",
    "工本费": "Processing Fee",
}

# Get all extended terms combined
def get_all_extended_terms() -> Dict[str, str]:
    """Get all extended terms combined."""
    return EXTENDED_BANK_TERMS.copy()
