"""Overlay-based Chinese->English translation renderer for PDFs."""

from __future__ import annotations

import re
from dataclasses import dataclass
from io import BytesIO
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import fitz
import pdfplumber
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen import canvas

from config import Settings, get_settings
from translator import StatementTranslator


CHINESE_BLOCK_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]+")


@dataclass(frozen=True)
class TextBlock:
    """Extracted text block with page location metadata."""

    page_index: int
    block_index: int
    bbox: Tuple[float, float, float, float]
    text: str


@dataclass(frozen=True)
class WordSpan:
    """Single text span extracted from a PDF page."""

    text: str
    x0: float
    x1: float
    top: float
    bottom: float


@dataclass(frozen=True)
class OverlaySpan:
    """Translated span positioned in page coordinates."""

    text: str
    x0: float
    x1: float
    top: float
    bottom: float


def extract_text_blocks_with_positions(pdf_path: str) -> List[TextBlock]:
    """Extract all text blocks with exact page positions via pdfplumber."""
    blocks: List[TextBlock] = []

    with pdfplumber.open(pdf_path) as pdf:
        for page_index, page in enumerate(pdf.pages):
            words = page.extract_words(
                keep_blank_chars=True,
                use_text_flow=True,
                split_at_punctuation=False,
            )
            for block_index, word in enumerate(words):
                text = str(word.get("text", ""))
                if not text:
                    continue
                blocks.append(
                    TextBlock(
                        page_index=page_index,
                        block_index=block_index,
                        bbox=(
                            float(word.get("x0", 0.0)),
                            float(word.get("top", 0.0)),
                            float(word.get("x1", 0.0)),
                            float(word.get("bottom", 0.0)),
                        ),
                        text=text,
                    )
                )

    return blocks


def translate_pdf_in_place(
    input_pdf_path: str,
    output_pdf_path: str,
    settings: Optional[Settings] = None,
    translate_fn: Optional[Callable[[str], str]] = None,
) -> str:
    """
    Rebuild PDF by drawing original page backgrounds and overlaying translated text.

    Despite the historic name, this does not edit PDF objects in-place.
    """
    translator = translate_fn or _build_translator(settings or get_settings())
    cache: Dict[str, str] = {}

    with pdfplumber.open(input_pdf_path) as plumber_pdf, fitz.open(input_pdf_path) as fitz_doc:
        output_canvas = canvas.Canvas(output_pdf_path)

        for page_index, plumber_page in enumerate(plumber_pdf.pages):
            fitz_page = fitz_doc[page_index]
            page_width = float(plumber_page.width)
            page_height = float(plumber_page.height)

            output_canvas.setPageSize((page_width, page_height))
            _draw_page_background(output_canvas, fitz_page, page_width, page_height)

            words = _extract_word_spans(plumber_page)
            lines = _group_words_by_lines(words)
            overlays = _build_line_overlays(lines, translator, cache)

            for overlay in overlays:
                _draw_overlay_span(output_canvas, overlay, page_height)

            output_canvas.showPage()

        output_canvas.save()

    return output_pdf_path


def _draw_page_background(
    output_canvas: canvas.Canvas,
    fitz_page: fitz.Page,
    page_width: float,
    page_height: float,
) -> None:
    pixmap = fitz_page.get_pixmap(alpha=False)
    image_stream = BytesIO(pixmap.tobytes("png"))
    image_reader = ImageReader(image_stream)
    output_canvas.drawImage(
        image_reader,
        0,
        0,
        width=page_width,
        height=page_height,
        preserveAspectRatio=False,
        mask="auto",
    )


def _extract_word_spans(page: pdfplumber.page.Page) -> List[WordSpan]:
    raw_words = page.extract_words(
        keep_blank_chars=True,
        use_text_flow=True,
        split_at_punctuation=False,
    )

    spans: List[WordSpan] = []
    for word in raw_words:
        text = str(word.get("text", ""))
        if not text.strip():
            continue

        spans.append(
            WordSpan(
                text=text,
                x0=float(word.get("x0", 0.0)),
                x1=float(word.get("x1", 0.0)),
                top=float(word.get("top", 0.0)),
                bottom=float(word.get("bottom", 0.0)),
            )
        )

    return spans


def _group_words_by_lines(words: Sequence[WordSpan], tolerance: float = 2.5) -> List[List[WordSpan]]:
    if not words:
        return []

    ordered = sorted(words, key=lambda span: (span.top, span.x0))
    lines: List[List[WordSpan]] = []

    for span in ordered:
        if not lines:
            lines.append([span])
            continue

        current_line = lines[-1]
        line_top = sum(item.top for item in current_line) / len(current_line)
        if abs(span.top - line_top) <= tolerance:
            current_line.append(span)
            current_line.sort(key=lambda item: item.x0)
        else:
            lines.append([span])

    return lines


def _build_line_overlays(
    lines: Sequence[Sequence[WordSpan]],
    translator: Callable[[str], str],
    cache: Dict[str, str],
) -> List[OverlaySpan]:
    overlays: List[OverlaySpan] = []

    for line in lines:
        for span in line:
            if not CHINESE_BLOCK_RE.search(span.text):
                continue

            translated = _translate_chinese_segments(span.text, translator, cache)
            translated = translated.strip()
            if not translated or translated == span.text:
                continue

            overlays.append(
                OverlaySpan(
                    text=translated,
                    x0=span.x0,
                    x1=span.x1,
                    top=span.top,
                    bottom=span.bottom,
                )
            )

    return overlays


def _translate_chinese_segments(
    text: str,
    translator: Callable[[str], str],
    cache: Dict[str, str],
) -> str:
    def replace(match: re.Match[str]) -> str:
        source = match.group(0)
        if source in cache:
            return cache[source]

        translated = translator(source).strip()
        cache[source] = translated or source
        return cache[source]

    return CHINESE_BLOCK_RE.sub(replace, text)


def _draw_overlay_span(output_canvas: canvas.Canvas, span: OverlaySpan, page_height: float) -> None:
    box_width = max(1.0, span.x1 - span.x0)
    box_height = max(1.0, span.bottom - span.top)

    # pdfplumber uses top-origin Y, reportlab uses bottom-origin Y.
    y_bottom = page_height - span.bottom

    output_canvas.setFillColorRGB(1, 1, 1)
    output_canvas.rect(span.x0, y_bottom, box_width, box_height, fill=1, stroke=0)

    font_name = "Helvetica"
    font_size = _fit_font_size(span.text, font_name, box_width, box_height)

    output_canvas.setFillColorRGB(0, 0, 0)
    output_canvas.setFont(font_name, font_size)

    baseline = y_bottom + max(0.0, (box_height - font_size) / 2.0)
    output_canvas.drawString(span.x0, baseline, span.text)


def _fit_font_size(text: str, font_name: str, max_width: float, max_height: float) -> float:
    if not text:
        return 8.0

    size = min(max_height * 0.9, 12.0)
    size = max(size, 4.0)

    while size > 4.0:
        width = pdfmetrics.stringWidth(text, font_name, size)
        if width <= max_width:
            return size
        size -= 0.5

    return 4.0


def _build_translator(settings: Settings) -> Callable[[str], str]:
    statement_translator = StatementTranslator(settings)

    def translate(text: str) -> str:
        glossary_hit = settings.glossary.get(text)
        if glossary_hit:
            return glossary_hit

        translated = statement_translator._translate_text(text)  # noqa: SLF001
        return translated if translated else text

    return translate


# Backward-compatibility wrappers for prior callers.
def pdf_to_word(pdf_path: str, word_path: str) -> str:
    raise NotImplementedError(
        "DOCX conversion is not supported. Use translate_pdf_in_place(input_pdf, output_pdf) instead."
    )


def translate_word(
    input_docx_path: str,
    output_docx_path: str,
    settings: Optional[Settings] = None,
    translate_fn: Optional[Callable[[str], str]] = None,
) -> str:
    # Kept for compatibility with legacy callers that route through this name.
    return translate_pdf_in_place(
        input_docx_path,
        output_docx_path,
        settings=settings,
        translate_fn=translate_fn,
    )


def word_to_pdf(word_path: str, pdf_path: str) -> str:
    raise NotImplementedError(
        "DOCX conversion is not supported. Use translate_pdf_in_place(input_pdf, output_pdf) instead."
    )
