from pathlib import Path

from word_translator import translate_pdf_in_place


def main() -> None:
    input_pdf = Path("test_statement.pdf")
    output_pdf = Path("test_overlay_translated.pdf")

    if not input_pdf.exists():
        raise FileNotFoundError("test_statement.pdf not found")

    translate_pdf_in_place(str(input_pdf), str(output_pdf))
    print(f"Generated: {output_pdf}")


if __name__ == "__main__":
    main()
