"""Translation module for bank statements with aggressive Chinese cleanup."""

from __future__ import annotations

import re
import time
from typing import Dict, Iterable, Optional

import pandas as pd
import requests

from cache import get_cache
from config import Settings
from logger import get_logger


logger = get_logger(__name__)


def retry_on_error(max_retries: int = 3, delay: float = 1.0):
    """Decorator to retry function on error."""
    def decorator(func):
        def wrapper(*args, **kwargs):
            last_error = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_error = e
                    logger.warning(f"Attempt {attempt + 1}/{max_retries} failed: {e}")
                    if attempt < max_retries - 1:
                        time.sleep(delay * (attempt + 1))  # Exponential backoff
            logger.error(f"All {max_retries} attempts failed")
            raise last_error
        return wrapper
    return decorator


TRANSLATABLE_COLUMNS = (
    "摘要",
    "地区",
    "对方户名",
    "对方账号",
    "渠道",
    "储种",
    "币种",
    "钞汇",
)

CHINESE_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
CHINESE_BLOCK_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]+")
WHITESPACE_RE = re.compile(r"\s+")


BANK_TERMS: Dict[str, str] = {
    "（空）": "",
    "(空)": "",
    "空": "",
    "无": "",
    "摘要": "Description",
    "地区": "Region",
    "对方户名": "Counterparty Name",
    "对方账号": "Counterparty Account",
    "渠道": "Channel",
    "储种": "Savings Type",
    "币种": "Currency",
    "钞汇": "Cash/Transfer",
    "收入": "Income",
    "支出": "Expenditure",
    "收入/支出": "Income/Expenditure",
    "收入/支出金额": "Income/Expenditure Amount",
    "转账": "Transfer",
    "转入": "Transfer In",
    "转出": "Transfer Out",
    "来账": "Incoming Transfer",
    "往账": "Outgoing Transfer",
    "汇入": "Incoming Remittance",
    "汇出": "Outgoing Remittance",
    "消费": "Consumption",
    "退款": "Refund",
    "还款": "Repayment",
    "贷款还款": "Loan Repayment",
    "信用卡还款": "Credit Card Repayment",
    "工资": "Salary",
    "代发工资": "Payroll",
    "奖金": "Bonus",
    "利息": "Interest",
    "结息": "Interest Settlement",
    "手续费": "Service Fee",
    "工本费": "Card Production Fee",
    "年费": "Annual Fee",
    "账户管理费": "Account Management Fee",
    "提现": "Withdrawal",
    "现金存入": "Cash Deposit",
    "现金支取": "Cash Withdrawal",
    "充值": "Top Up",
    "扣款": "Debit",
    "代扣": "Auto Debit",
    "代收": "Collection",
    "快捷支付": "Quick Payment",
    "网上支付": "Online Payment",
    "无卡支付": "Cardless Payment",
    "扫码支付": "QR Code Payment",
    "手机银行": "Mobile Banking",
    "网上银行": "Online Banking",
    "自助终端": "Self-Service Terminal",
    "柜台": "Counter",
    "现金": "Cash",
    "现汇": "Remittance",
    "现钞": "Cash",
    "钞": "Cash",
    "汇": "Remittance",
    "活期": "Demand Deposit",
    "定期": "Time Deposit",
    "人民币": "CNY",
    "美元": "USD",
    "欧元": "EUR",
    "英镑": "GBP",
    "港币": "HKD",
    "日元": "JPY",
    "澳元": "AUD",
    "加元": "CAD",
    "新加坡元": "SGD",
    "中国工商银行": "Industrial and Commercial Bank of China",
    "工商银行": "ICBC",
    "中国农业银行": "Agricultural Bank of China",
    "农业银行": "ABC",
    "中国银行": "Bank of China",
    "中国建设银行": "China Construction Bank",
    "建设银行": "CCB",
    "交通银行": "Bank of Communications",
    "招商银行": "China Merchants Bank",
    "平安银行": "Ping An Bank",
    "兴业银行": "Industrial Bank",
    "中信银行": "China CITIC Bank",
    "邮储银行": "Postal Savings Bank of China",
    "中国邮政储蓄银行": "Postal Savings Bank of China",
    "浦发银行": "Shanghai Pudong Development Bank",
    "民生银行": "China Minsheng Bank",
    "光大银行": "China Everbright Bank",
    "华夏银行": "Huaxia Bank",
    "北京银行": "Bank of Beijing",
    "上海银行": "Bank of Shanghai",
    "江苏银行": "Bank of Jiangsu",
    "浙商银行": "China Zheshang Bank",
    "恒丰银行": "Evergrowing Bank",
    "渤海银行": "Bohai Bank",
    "支付宝": "Alipay",
    "微信支付": "WeChat Pay",
    "财付通": "Tenpay",
    "银联": "UnionPay",
    "云闪付": "UnionPay QuickPass",
    "美团": "Meituan",
    "京东": "JD",
    "淘宝": "Taobao",
    "天猫": "Tmall",
    "拼多多": "Pinduoduo",
    "滴滴出行": "Didi",
    "饿了么": "Eleme",
    "盒马": "Freshippo",
    "腾讯": "Tencent",
    "阿里巴巴": "Alibaba",
    "字节跳动": "ByteDance",
    "百度": "Baidu",
    "网易": "NetEase",
    "小米": "Xiaomi",
    "华为": "Huawei",
    "中国移动": "China Mobile",
    "中国联通": "China Unicom",
    "中国电信": "China Telecom",
    "国家电网": "State Grid",
    "南方电网": "China Southern Power Grid",
    "中国石油": "PetroChina",
    "中国石化": "Sinopec",
    "有限公司": "Co Ltd",
    "有限责任公司": "Co Ltd",
    "股份有限公司": "Co Ltd",
    "科技有限公司": "Technology Co Ltd",
    "网络技术有限公司": "Network Technology Co Ltd",
    "支付科技有限公司": "Payment Technology Co Ltd",
    "平台商户": "Platform Merchant",
    "便利店": "Convenience Store",
    "超市": "Supermarket",
    "商店": "Store",
    "门店": "Store",
    "广场": "Plaza",
    "地铁": "Metro",
    "出口": "Exit",
    "武汉": "Wuhan",
    "深圳": "Shenzhen",
    "北京": "Beijing",
    "上海": "Shanghai",
    "广州": "Guangzhou",
    "杭州": "Hangzhou",
    "成都": "Chengdu",
    "南京": "Nanjing",
    "苏州": "Suzhou",
    "天津": "Tianjin",
    "重庆": "Chongqing",
    "西安": "Xi'an",
    "长沙": "Changsha",
    "郑州": "Zhengzhou",
    "青岛": "Qingdao",
    "宁波": "Ningbo",
    "无锡": "Wuxi",
    "厦门": "Xiamen",
    "福州": "Fuzhou",
    "济南": "Jinan",
    "大连": "Dalian",
    "沈阳": "Shenyang",
    "哈尔滨": "Harbin",
    "长春": "Changchun",
    "石家庄": "Shijiazhuang",
    "昆明": "Kunming",
    "贵阳": "Guiyang",
    "南宁": "Nanning",
    "南昌": "Nanchang",
    "合肥": "Hefei",
    "太原": "Taiyuan",
    "兰州": "Lanzhou",
    "乌鲁木齐": "Urumqi",
    "拉萨": "Lhasa",
    "呼和浩特": "Hohhot",
    "银川": "Yinchuan",
    "西宁": "Xining",
    "东莞": "Dongguan",
    "佛山": "Foshan",
    "中山": "Zhongshan",
    "珠海": "Zhuhai",
    "惠州": "Huizhou",
    "汕头": "Shantou",
}


class StatementTranslator:
    """Translate bank statement fields and remove all Chinese characters."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.cache: Dict[str, str] = {}
        self._session = requests.Session()
        glossary = dict(BANK_TERMS)
        glossary.update(settings.glossary)
        self._glossary = glossary
        self._phrase_glossary = dict(
            sorted(glossary.items(), key=lambda item: len(item[0]), reverse=True)
        )

    def translate_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df

        out = df.copy()
        for column in TRANSLATABLE_COLUMNS:
            if column not in out.columns:
                continue
            series = out[column].fillna("").astype(str)
            mapping = self._build_translation_map(series.unique().tolist())
            out[column] = series.map(lambda value: mapping.get(value, self._finalize_text(value)))
            out[column] = out[column].map(self._finalize_text)

        return out

    def _build_translation_map(self, texts: Iterable[str]) -> Dict[str, str]:
        mapping: Dict[str, str] = {}
        for original in texts:
            normalized = self._normalize_text(original)
            if not normalized:
                mapping[original] = ""
                continue

            if normalized in self.cache:
                mapping[original] = self.cache[normalized]
                continue

            translated = self._translate_text(normalized)
            translated = self._finalize_text(translated)
            self.cache[normalized] = translated
            mapping[original] = translated

        return mapping

    def _translate_text(self, text: str) -> str:
        # Check cache first
        cache = get_cache()
        cached = cache.get_translation(text)
        if cached is not None:
            logger.debug(f"Cache hit for: {text[:30]}...")
            return cached
        
        if text in self._glossary:
            result = self._glossary[text]
            cache.set_translation(text, result)
            return result

        replaced = self._replace_known_terms(text)
        if not self._contains_chinese(replaced):
            cache.set_translation(text, replaced)
            return replaced

        translated = self._call_glm_strict(replaced)
        translated = self._replace_known_terms(translated)

        if self._contains_chinese(translated):
            translated = self._translate_residual_blocks(translated)

        if self._contains_chinese(translated):
            translated = self._strip_or_mark_residual(translated)
        
        # Cache the result
        cache.set_translation(text, translated)
        
        return translated

    def _replace_known_terms(self, text: str) -> str:
        replaced = self._normalize_text(text)
        if replaced in self._glossary:
            return self._glossary[replaced]

        for source, target in self._phrase_glossary.items():
            if source and source in replaced:
                replaced = replaced.replace(source, target)

        return self._normalize_spacing(replaced)

    def _translate_residual_blocks(self, text: str) -> str:
        result = text
        for block in sorted(set(CHINESE_BLOCK_RE.findall(text)), key=len, reverse=True):
            if not block.strip():
                continue
            translated = self._call_glm_strict(block)
            translated = self._replace_known_terms(translated)
            translated = self._strip_or_mark_residual(translated)
            result = result.replace(block, translated)
        return result

    def _strip_or_mark_residual(self, text: str) -> str:
        if not text:
            return text

        replaced = self._replace_known_terms(text)
        if not self._contains_chinese(replaced):
            return replaced

        # If still has Chinese, try to clean it by removing remaining Chinese blocks
        sanitized = CHINESE_BLOCK_RE.sub(" ", replaced)
        sanitized = self._normalize_spacing(sanitized)
        
        # If we got something meaningful after cleaning, use it
        if sanitized and sanitized != "[Untranslated]":
            return sanitized
        
        # If the text contains garbled characters (common in PDF extraction),
        # remove all non-ASCII characters as they're likely unreadable
        # Keep only ASCII characters and common punctuation
        cleaned = ''.join(c if ord(c) < 128 or c in ' ,.()[]{}' else ' ' for c in replaced)
        cleaned = self._normalize_spacing(cleaned)
        
        # If still empty, return empty string
        return cleaned if cleaned else ""

    def _finalize_text(self, text: str) -> str:
        cleaned = self._normalize_text(text)
        cleaned = self._replace_known_terms(cleaned)
        if self._contains_chinese(cleaned):
            cleaned = self._translate_residual_blocks(cleaned)
        if self._contains_chinese(cleaned):
            cleaned = self._strip_or_mark_residual(cleaned)
        return self._normalize_spacing(cleaned)

    def _normalize_text(self, text: str) -> str:
        if text is None:
            return ""

        value = str(text).strip()
        if not value:
            return ""

        value = (
            value.replace("\u3000", " ")
            .replace("（", "(")
            .replace("）", ")")
            .replace("，", ",")
            .replace("：", ":")
            .replace("；", ";")
            .replace("。", ".")
            .replace("、", "/")
            .replace("“", '"')
            .replace("”", '"')
            .replace("‘", "'")
            .replace("’", "'")
        )
        return self._normalize_spacing(value)

    def _normalize_spacing(self, text: str) -> str:
        text = WHITESPACE_RE.sub(" ", text).strip()
        text = re.sub(r"\s+([,;:/)])", r"\1", text)
        text = re.sub(r"([(])\s+", r"\1", text)
        return text.strip("[]{}\"'")

    def _contains_chinese(self, text: str) -> bool:
        return bool(CHINESE_RE.search(text))

    def _call_glm_strict(self, text: str) -> str:
        if not text:
            return ""
        if not self.settings.api_key:
            return text

        headers = {
            "Authorization": f"Bearer {self.settings.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.settings.model_name,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "Translate the user text into concise natural English for a bank statement. "
                        "Return only English text. Never output Chinese characters. "
                        "Preserve numbers, masked account numbers, dates, and merchant identity."
                    ),
                },
                {"role": "user", "content": text},
            ],
            "temperature": 0.1,
        }

        for attempt in range(3):
            try:
                response = self._session.post(
                    self.settings.api_url,
                    headers=headers,
                    json=payload,
                    timeout=self.settings.request_timeout_sec,
                )
                if response.status_code == 429:
                    time.sleep(2 ** attempt)
                    continue

                response.raise_for_status()
                content = self._extract_response_text(response)
                if not content:
                    continue

                cleaned = self._normalize_spacing(content)
                if cleaned:
                    return cleaned
            except Exception:
                pass

            if attempt < 2:
                time.sleep(1)

        return text

    def _extract_response_text(self, response: requests.Response) -> str:
        data = response.json()
        choices = data.get("choices", [])
        if not choices:
            return ""
        message = choices[0].get("message", {})
        return str(message.get("content", "")).strip()
